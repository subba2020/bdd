package com.example.bbdlatest;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.assertEquals;

public class StepDefinations {
    private RestTemplate restTemplate = new RestTemplate();
    String url="http://localhost:9090/customer";
    ResponseEntity<String> response = null;
    @Given("I can get customer data")
    public void i_can_get_customer_data() {
        response= restTemplate.getForEntity(url,String.class);
        System.out.println("response is:"+response.toString());

    }

    @Then("I should be able to see customer data")
    public void i_should_be_able_to_see_customer_data() {
        String responseValue = response.getBody();
        assertEquals("subba",responseValue);
    }
}
