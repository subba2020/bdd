package com.example.bbdlatest;

import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
       //tags = { "@rajan" },
        plugin = {"pretty","html:target/cucumberreport.html.report"
        ,"json:target/cucumber.json"},
        features = "classpath:features"
)
public class CucumberRunnerTest {
}
